---
name: project-context-loader
description: Load project context from worklog directory when starting daily work. Use this skill when the user indicates they are starting work for the day or wants to review project status. Automatically loads project overview, development guidelines, and recent work logs to provide comprehensive project context.
---

# Project Context Loader

## Overview

Load comprehensive project context from the worklog directory when starting daily work. This skill automatically reads the project overview, development guidelines, and recent work logs to help AI assistants quickly understand the project status and continue work seamlessly.

## When to Use This Skill

This skill should be triggered when:
- User says "开始工作", "start work", "今天的工作", or similar phrases indicating the start of daily work
- User wants to review project status and recent progress
- User opens a new conversation session and wants to understand the project context
- User asks about project overview or work history

## Core Workflow

### Step 1: Identify Worklog Directory

Locate the worklog directory at the project root:
```
<workspace>/worklog/
```

If the worklog directory does not exist, inform the user and suggest alternative ways to understand the project.

### Step 2: Load Core Documents

Read the following files in order:

1. **Project Overview** - `worklog/README.md`
   - Project background and positioning
   - Technical stack and architecture
   - Core features and design principles
   - Development progress and milestones

2. **Development Guidelines** - `worklog/rules.md`
   - Coding standards and best practices
   - Design principles (SOLID, DRY, KISS, etc.)
   - Code review checklist
   - Testing and security requirements

### Step 3: Load Recent Work Logs

Identify and read the most recent work logs:

1. List all date directories in worklog/ (format: YYYY-MM-DD)
2. Sort by date (descending)
3. Read README.md from the latest 3-5 date directories
4. Summarize recent work progress and achievements

### Step 4: Check Project Status

Examine current project state:

1. **Git Status**: Check for uncommitted changes
2. **Current Branch**: Identify the working branch
3. **Recent Commits**: Review latest commit messages
4. **Pending Tasks**: Identify incomplete tasks from work logs

### Step 5: Present Context Summary

Provide a comprehensive summary including:

#### Project Overview
- Project name and current phase
- MVP scope and validation goals
- Technology stack highlights

#### Recent Progress
- Latest work date and achievements
- Key deliverables from recent sessions
- Important technical decisions made

#### Current Status
- Active features or components
- Known issues or blockers
- Uncommitted work in progress

#### Next Steps
- Pending tasks from work logs
- Recommended priorities
- Immediate action items

## Implementation Details

### File Reading Strategy

When loading work logs:
- Always read README.md files first for overview
- Optionally read specific topic files if mentioned in README
- For large files, consider reading in sections if needed

### Context Prioritization

Focus on:
1. **Project overview** - Essential for understanding
2. **Recent work** - Most relevant for continuity
3. **Development rules** - Important for consistency
4. **Historical records** - Reference as needed

### Handling Missing Information

If certain files are missing:
- Worklog directory not found: Check project structure, suggest alternatives
- README.md missing: Note the absence, continue with available files
- No recent work logs: Focus on project overview and current git status

## Reference

For detailed information about the worklog directory structure, see: `references/worklog_structure.md`

## Example Usage

**User**: "开始今天的工作"

**AI Response**:
1. Read worklog/README.md - Get project overview
2. Read worklog/rules.md - Get development guidelines
3. List worklog/ subdirectories - Find recent dates
4. Read latest 3 README.md files - Get recent progress
5. Check git status - Get current state
6. Present comprehensive context summary

**Output Example**:
```
# 项目上下文加载完成

## 项目概况
- 项目: AI 虚拟教师系统
- 当前阶段: MVP 开发阶段
- 技术栈: React + TypeScript (前端), Python FastAPI (后端)

## 最近进展 (2026-04-10)
- 完成教学图片生成方案的深度探索
- 提出"模板驱动+混合策略"方案
- 创建多个演示脚本和可视化示例

## 当前状态
- 工作分支: feature-zhaoyangyang
- 未提交文件: 约15个新增文件
- 主要工作: 教学图片生成方案验证

## 下一步建议
1. 将模板方案集成到 AI 教师系统
2. 建立模板库覆盖常见教学场景
3. 编写 LLM 参数化 Prompt

准备好开始工作了!请问今天要做什么?
```
